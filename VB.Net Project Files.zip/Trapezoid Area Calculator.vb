Module KhianVictoryDCalderon_Net_Technology_PT_6
    Sub Main()
        Console.clear() 'clear console'
        Dim b1,b2,h,a,ax as Integer 
        'b1 for base 1 , b2 for base 2'
        'h for height , a for area , ax for math area'
        
        'block 1 , get inputs first'
        b1 = Console.ReadLine()
        b2 = Console.ReadLine()
        h = Console.ReadLine()
        
        'block 2 , formulas'
        a = b1 + b2 * h / 2
        ax = (((b1 + b2) * h) / 2)
        'in terms of math'
        
        'block 3 , outputs'
        Console.WriteLine(" ")
        Console.WriteLine(" ")
        Console.WriteLine("Based 1 of Trapezoid is {0}",b1)
        Console.WriteLine("Based 2 of Trapezoid is {0}",b2)
        Console.WriteLine("Height of Trapezoid is {0}",h)
        Console.WriteLine(" ")
        Console.WriteLine("Area of Trapezoid is {0}",a)
        Console.WriteLine(" ")
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("Grade 11 - Demeter")
        Console.WriteLine(" ")
        Console.WriteLine(" ")
        Console.WriteLine("In terms of Math , Area of Trapezoid is {0}",ax)
    End Sub
End Module