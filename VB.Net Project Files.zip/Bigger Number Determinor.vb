Module VBNet
 Sub Main()
  Dim num1,num2 as Integer
  num1 = Console.ReadLine()
  num2 = Console.ReadLine()
  if num1 > num2
  Console.writeline("{0} is bigger than {1}",num1,num2)
  else if num2 > num1
  Console.writeline("{0} is bigger than {1}",num2,num1)
  else if num1 = num2
  Console.writeline("{0} and {1} are the same",num2,num1)
  end if
  Console.writeline("Bigger number Determinor")
 End Sub
End Module