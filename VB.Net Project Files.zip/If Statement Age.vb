Module Task4_IfElse_by_Khian
    Dim Input as Integer
    Sub Main()
        Console.Clear()
        Console.WriteLine(" ") ' Serves as a placeholder
        Console.WriteLine("I Am Khian Victory D. Calderon")
        Input = Console.ReadLine()
        Console.WriteLine(" ") ' Serves as a placeholder
        Console.Write("Input Age : ")
        Console.WriteLine("{0}",Input)
        If Input<=0
           Console.WriteLine("Sorry Di ka pa Pinapanganak Sa Mundo")
        ElseIf Input>0 and Input<=12
           Console.WriteLine("Isa kang KIDS")
        ElseIf Input>=13 and Input<=19
           Console.WriteLine("Isa kang TEENS")
        ElseIf Input>=20 and Input<=59
           Console.WriteLine("Isa kang ADULT")
        ElseIf Input>=60 and Input<=100
           Console.WriteLine("Isa kang SENIOR")
        Else
           Console.WriteLine("Isa kang IMMORTAL NA NILALANG")
        End If
    End Sub
End Module