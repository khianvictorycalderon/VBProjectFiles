Module VBNet
 Sub Main()
 Dim choice as char
 Console.WriteLine("Pythagorean Theorem Formula")
 Console.WriteLine("What would you like to find?")
 Console.WriteLine("a. Hypotenuse")
 Console.WriteLine("b. One of the 2 Legs")
 choice = Console.ReadLine()
 
 Dim leg1, leg2, h as Decimal
 if choice = "a"
  Console.WriteLine("Enter 2 leg input, finds the hypotenuse")
  leg1 = Console.readline()
  leg2 = Console.readline()
  h = Math.Sqrt((leg1 * leg1) + (leg2 * leg2))
  Console.writeline("The hypotenuse is {0}",h)
 else if choice = "b"
  Console.WriteLine("Enter the hypotenuse first and then one of the legs")
  h = Console.readline()
  leg1 = Console.readline()
  leg2 = Math.Sqrt((h * h) - (leg1 * leg1))
  Console.writeline("The leg is {0}",leg2)
 else
  Console.WriteLine("Invalid Input")
 end if
End Sub
End Module