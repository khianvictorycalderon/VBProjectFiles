Module VBNet
 Sub Main()
  Dim pass as string 
  Console.WriteLine("Simple Password system")
  Console.WriteLine("Enter the password 1234")
  pass = Console.ReadLine()
  if pass = "1234"
   Console.WriteLine("Password is Correct")
  else 
   Console.WriteLine("Password is Incorrect")
  end if
 End Sub
End Module