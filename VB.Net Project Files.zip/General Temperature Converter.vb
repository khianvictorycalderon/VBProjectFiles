Module Task4and5NetTechnologyKhianCalderon 'declares the name of the module
    Sub Main() 'main block of the program
        Dim C,F,R as Decimal 'input variables declaration
        Dim CtF,CtK,CtR as Decimal 'centigrade variables declaration
        Dim FtC,FtK,FtR as Decimal 'fahrenheit variables declaration
        Dim RtC,RtK,RtF as Decimal 'rankine variables declaration
        Console.clear() 'clears the console initially
        Console.WriteLine("Temperature CONVERTER")'displays this text
        Console.WriteLine("INPUT VALUE FOR TEMPERATURE : ")'displays this text
        Console.WriteLine("")'serves as a placeholder
        C = Console.ReadLine() 'get user input and assign it to this variable
        F = Console.ReadLine() 'get user input and assign it to this variable
        R = Console.ReadLine() 'get user input and assign it to this variable
        Console.WriteLine("")'serves as a placeholder
        Console.WriteLine("Input Value for Centigrade is : {0}",C)'display the value of this variable
        Console.WriteLine("Input Value for Fahrenheit is : {0}",F)'display the value of this variable
        Console.WriteLine("Input Value for Rankine is : {0}",R)'display the value of this variable
        
        Console.WriteLine("")'serves as a placeholder
        CtF = C * 1.8 + 32 'formula of this variable
        CtK = C + 273.15 'formula of this variable
        CtR = (C + 273.15) * 9/5 'formula of this variable
        Console.WriteLine("CENTIGRADE CONVERSION")'displays this text
        Console.WriteLine("Centigrade to Fahrenheit Convertion is equal to : {0}",CtF)'display the value of this variable
        Console.WriteLine("Centigrade to Kelvin Convertion is equal to : {0}",CtK)'display the value of this variable
        Console.WriteLine("Centigrade to Rankine Convertion is equal to : {0}",CtR)'display the value of this variable
        
        Console.WriteLine("")'serves as a placeholder
        FtC = (F - 32) * 5/9 'formula of this variable
        FtK = ((F - 32) * 5/9) + 273.15 'formula of this variable
        FtR = F + 459.67 'formula of this variable
        Console.WriteLine("FAHRENHEIT CONVERSION")'displays this text
        Console.WriteLine("Fahrenheit to Centigrade Convertion is equal to : {0}",FtC)'display the value of this variable
        Console.WriteLine("Fahrenheit to Kelvin Convertion is equal to : {0}",FtK)'display the value of this variable
        Console.WriteLine("Fahrenheit to Rankine Convertion is equal to : {0}",FtR)'display the value of this variable
        
        Console.WriteLine("")'serves as a placeholder
        RtC = (R * 5/9) - 273.15 'formula of this variable
        RtK = R / 1.8 'formula of this variable
        RtF = R - 459.67 'formula of this variable
        Console.WriteLine("RANKINE CONVERSION")'displays this text
        Console.WriteLine("Rankine to Centigrade Convertion is equal to : {0}",RtC)'display the value of this variable
        Console.WriteLine("Rankine to Kelvin Convertion is equal to : {0}",RtK)'display the value of this variable
        Console.WriteLine("Rankine to Fahrenheit Convertion is equal to : {0}",RtF)'display the value of this variable
    
        Console.WriteLine("")'serves as a placeholder
        Console.WriteLine("Khian Victory D. Calderon")'displays this text
        Console.WriteLine("Grade 11 - Demeter")'displays this text
    End Sub 'encloses the sub main()
End Module 'encloses the module