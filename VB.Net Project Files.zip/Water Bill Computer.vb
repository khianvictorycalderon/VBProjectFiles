Module VBNet
 Sub Main()
  Dim bill,cum as Decimal
  Dim ch as char
  Console.WriteLine("What will compute? (Residential Type Only)")
  Console.WriteLine("a. Cubic Per Meter (CUM)")
  Console.WriteLine("b. Water Bill")
  ch = Console.ReadLine()
  if ch = "a"
  Console.WriteLine("How much is your bill in pesos in the last 31 Days without tax?")
  bill = Console.ReadLine()
  Console.WriteLine("Your bill is {0}",bill)
  cum = bill / 21
  Console.WriteLine("You used about {0} Cubic Meter of Water in 31 Days",cum)
  else if ch = "b"
   Console.WriteLine("How much Cubic Meter of Water did you used in the last 31 Days?")
   cum = Console.ReadLine()
   Console.WriteLine("Your Cubic Meter of Water is {0}",cum)
   bill = cum * 21
   Console.WriteLine("Your water bill is about {0} pesos in 31 Days on DUE with tax included",bill + ((bill * 12)/100))
  else 
   Console.WriteLine("Invalid Input")
  end if
 End Sub
End Module