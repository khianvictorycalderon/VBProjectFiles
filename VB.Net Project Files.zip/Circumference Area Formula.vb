Module Calderon_Khian_Performance_7_Net_Technology
 Sub Main()
  Console.clear()
  Dim rd,ar,cf,di,rt as Decimal
  'rd for radius , ar for area , cf for circumference , di for diamater , rt for ratio'
  rd = Console.ReadLine()
  di = rd * 2
  ar = 3.14 * (rd * rd)
  cf = 2 * 3.14 * rd
  di = rd * 2
  rt = ar / (rd * rd)
  Console.WriteLine("Radius is {0}",rd)
  Console.WriteLine(" ")
  Console.WriteLine("Area of Circle is {0}",ar)
  Console.WriteLine("Circumference of Circle is {0}",cf)
  Console.WriteLine("Diameter of Circle is {0}",di)
  Console.WriteLine("Ratio of Circle is {0}",rt)
  Console.WriteLine(" ")
  Console.WriteLine("Khian Victory D. Calderon")
  Console.WriteLine("Grade 11 - Demeter")
 End Sub
End Module