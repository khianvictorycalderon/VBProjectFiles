Module VBModule
 Sub Main()
  for i as integer = 0 to 10 step 1 
   Console.WriteLine("{0}",i)
  next
  Console.WriteLine("End of For Loop")
 End Sub
End Module
