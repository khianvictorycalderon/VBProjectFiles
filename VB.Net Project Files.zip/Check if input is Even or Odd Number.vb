Module Task5NetTechnologyPart2CalderonKhian
    Sub Main()
        Console.Clear()
        Dim num,df as Integer 'declares num as variable
        num = Console.ReadLine() 'get user input
        df = num Mod 2 'determine if a number is divisible by 2
        'Mod is short for Modulo operator, this returns the remainder of a number
        'all even numbers divided by 2 has no remainder
        'all odd numbers divided by 2 has 1 remainder
        'i can use this as a basis to check if the number is odd or even
        'df is used for differentiating even or odd number
        If df = 1 'a df can't have a value of 2 that is shown in the flowchart
        Console.WriteLine("Your Input Value is {0} and this is odd number",num)
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("11 - Demeter")
        Else 
        Console.WriteLine("Your Input Value is {0} and this is even number",num)
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("11 - Demeter")
        End If
    End Sub
End Module