Module VBModule
 Sub Main()
  Console.clear()
  Console.WriteLine("Geometric and Arithmetic Calculator")
  Console.WriteLine("This program will determine if it is arithmetic or geometric sequence and its previous and next term")
  Console.WriteLine("")
  Console.WriteLine("Enter three input:")
  Dim num1, num2, num3 as Decimal 
  num1 = Console.ReadLine()
  num2 = Console.ReadLine() 
  num3 = Console.ReadLine()
  Dim cv as Decimal 'common value 
  Dim cr as Decimal 'common ratio
  cv = num2-num1
  cr = num2/num1
  if cr = 1 and cv = 0
   Console.WriteLine("The sequence is either geometric or arithmetic")
   Console.WriteLine("Common Value is {0}",cv)
   Console.WriteLine("Common Ratio is {0}",cr)
   Console.WriteLine("The following sequence are:")
   Console.WriteLine("{0} {1} {2} {3} {4}",num1/cr,num1,num2,num3,num3+cv)
  else if num2-num1 = num3-num2
   Console.WriteLine("It is an Arithmetic Sequence")
   Console.WriteLine("Common Value is {0}",cv)
   Console.WriteLine("The following sequence are:")
   Console.WriteLine("{0} {1} {2} {3} {4}",num1-cv,num1,num2,num3,num3+cv)
  else if num2/num1 = num3/num2
   Console.WriteLine("It is a Geometric Sequence")
   Console.WriteLine("Common Ratio is {0}",cr)
   Console.WriteLine("The following sequence are:")
   Console.WriteLine("{0} {1} {2} {3} {4}",num1/cr,num1,num2,num3,num3*cr)
  else
   Console.WriteLine("The sequence is neither geometric nor arithmetic")
  end if
 End Sub
End Module
