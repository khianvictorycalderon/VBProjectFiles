' code by khian victory d calderon
Module mcjvgnchunvcdjisvsd_Galing_Magturo_ni_Sir___Plus_Points_hehehe
    Dim input_1 As Integer
	Dim input_2 As Integer
	Dim sum As Integer ' sum of 2 input
	Dim dif As Integer ' difference of 2 input
	Dim pro As Integer ' product of 2 input
	Dim quo As Integer ' quotient of 2 input
	Sub Main()
		Console.WriteLine(" ") ' Serves as a placeholder
		Console.WriteLine("Your first input is : ")
		input_1 = Convert.ToInt64(Console.ReadLine())
		Console.WriteLine("Your last input is : ")
		input_2 = Convert.ToInt64(Console.ReadLine())
		sum = input_1 + input_2
		dif = input_1 - input_2
		pro = input_1 * input_2
		quo = input_1 / input_2
		Console.WriteLine("First input + last input is : {0}",sum)
		Console.WriteLine("First input - last input is : {0}",dif)
		Console.WriteLine("First input * last input is : {0}",pro)
		Console.WriteLine("First input / last input is : {0}",quo)
		Console.WriteLine("Submitted by : Khian Victory D. Calderon")
		Console.WriteLine("11 - Demeter")
		Console.ReadLine()' Prevents Console from closing
    End Sub
End Module