Module Task2NetTechnologyKhianVictoryDCalderon 'name of module
    Sub Main() 'main block of the program
        Console.Clear() 'clears the console
        Dim cS as String 'declares cS variable as String , stands for celsius String to be converted to double
        Dim c as Double 'declares c as Double , celsius must be double , does not need to be exact
        Dim f,k,r as Decimal 'declares f,k,r variable as decimal speed matters here which is decimal
        Console.WriteLine("Temperature Converter") 'displays a message
        Console.WriteLine("Enter celsius/centigrade input") 'displays a message
        loop1 : 'loop to go if the input is not a number
        Console.WriteLine("") 'serves as a placeholder
        cS = Console.ReadLine() 'get input from user and assign it to cS
        Console.WriteLine("") 'serves as a placeholder
        If IsNumeric(cS) Then 'this determines if the input is a number 
            c = CDbl(Val(cS)) 'Converts string to double
            f = c * 1.8 + 32 'fahrenheit formula
            k = c + 273.15 'kelvin formula
            r = c * 9/5 + 491.67 'rankine formula
            Console.WriteLine("Centigrade : {0}",c) 'displays centigrade
            Console.WriteLine("Fahrenheit : {0}",f) 'displays fahrenheit
            Console.WriteLine("Kelvin : {0}",k) 'displays kelvin
            Console.WriteLine("Rankine : {0}",r) 'displays rankine
            Console.WriteLine("") 'serves as a placeholder
            Console.WriteLine("Khian Victory D. Calderon") 'prints my name
            Console.WriteLine("Grade 11 - Demeter") 'prints my grade and section
         Else 'what to do if input is not a number
            Console.WriteLine("Invalid input, Numbers only!") 'displays a message
            Console.WriteLine("Enter celsius/centigrade input again!") 'displays a message
            goto loop1 'will loop if the input is not a number so no loophole
        End If 'encloses the if statement
    End Sub 'encloses the sub main()
End Module 'encloses the module
