Module OnlineClass 'declares module name which is the OnlineClass
 Sub Main() 'main block of the program, tells the computer to execute code inside
  Dim x, y, z as Integer 'declares variable x y and z
  Console.Clear() ' clears the console to avoid confusion (for me)
  Console.WriteLine("Hello World") 'tells the computer to print on screen
  x = Console.ReadLine() 'get user input and assign it to variable x
  y = Console.ReadLine() 'get user input and assign it to variable y
  z = x + y ' assign the value of z , x + y
  Console.WriteLine("The result is {0}",z) 'tells the computer to print variable z on screen
  Console.WriteLine("Operations are Samples Only") 'tells the computer to print on screen
  Console.WriteLine("") 'serves as a placeholder
  Console.WriteLine("Khian Victory D. Calderon") 'tells the computer to print on screen
  Console.WriteLine("ICT Grade 11 - Demeter") 'tells the computer to print on screen
  Console.WriteLine("All rights reserved 2022") 'tells the computer to print on screen
 End Sub 'encloses the sub main() and tells the computer to stop executing codes
End Module 'tells the computer that the module OnlineClass ends here