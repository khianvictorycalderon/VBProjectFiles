Module VBNet
 Sub Main()
  Dim bill,kwh as Decimal
  Dim ch as char
  Console.WriteLine("What will compute?")
  Console.WriteLine("a. Kilowatts Per Hour (KWH)")
  Console.WriteLine("b. Electric Bill")
  ch = Console.ReadLine()
  if ch = "a"
   Console.WriteLine("How much is your bill in pesos in the last 31 Days?")
   bill = Console.ReadLine()
   Console.WriteLine("Your bill is {0}",bill)
   kwh = bill / 10.58
   Console.WriteLine("You used about {0} Kilowatts of electricity in 31 Days",kwh)
  else if ch = "b"
   Console.WriteLine("How much KWH did you used in the last 31 Days?")
   kwh = Console.ReadLine()
   Console.WriteLine("Your KWH is {0}",kwh)
   bill = kwh * 10.58
   Console.WriteLine("Your electric bill is about {0} pesos in 31 Days",bill)
  else 
   Console.WriteLine("Invalid Input")
  end if
 End Sub
End Module