﻿Module function1
    Sub Main()
        Console.WriteLine(" ") 'Serves as an emtpry line
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("11 - Demeter")
        Console.WriteLine("Hello World")
    End Sub
End Module