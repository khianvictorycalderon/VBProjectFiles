Module VBNet
 Sub Main()
  Dim sc, n1, n2, ui as Integer
  sc = Math.Ceiling(Rnd() * 3)
  if sc=1 
   n1 = Math.Ceiling(Rnd() * 50)
   n2 = Math.Ceiling(Rnd() * 50)
   Console.WriteLine("What is {0} + {1}?",n1,n2)
   ui = Console.ReadLine()
   if ui=n1+n2
    Console.WriteLine("Correct!")
   else
    Console.WriteLine("Nice try, the correct answer is {0}",n1+n2)
   end if
  elseif sc=2
   n1 = Math.Ceiling(Rnd() * 50)
   n2 = Math.Ceiling(Rnd() * 50)
   Console.WriteLine("What is {0} - {1}?",n1,n2)
   ui = Console.ReadLine()
   if ui=n1-n2
    Console.WriteLine("Correct!")
   else
    Console.WriteLine("Nice try, the correct answer is {0}",n1-n2)
   end if
  elseif sc=3 
   n1 = Math.Ceiling(Rnd() * 20)
   n2 = Math.Ceiling(Rnd() * 20)
   Console.WriteLine("What is {0} × {1}?",n1,n2)
   ui = Console.ReadLine()
   if ui=n1*n2
    Console.WriteLine("Correct!")
   else
    Console.WriteLine("Nice try, the correct answer is {0}",n1*n2)
   end if
  end if
  Console.WriteLine("Quiz Operation Randomizer by")
  Console.WriteLine("Khian Victory D. Calderon")
 End Sub
End Module
