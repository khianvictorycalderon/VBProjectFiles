Module VBModule
 Sub Main()
  Console.Clear()
  Dim a, b, c, r1, r2 as Decimal
  Console.WriteLine("Quadratic Computer")
  Console.WriteLine("By Khian Victory D. Calderon")
  Console.WriteLine("")
  Console.WriteLine("Enter the 3 input from the quadratic equation: ")
  a = Console.ReadLine()
  b = Console.ReadLine()
  c = Console.ReadLine()
  r1 = ((b * -1) + Math.Sqrt((b * b) - (4 * a * c))) / (2 * a)
  r2 = ((b * -1) - Math.Sqrt((b * b) - (4 * a * c))) / (2 * a)
  Console.WriteLine("")
  Console.WriteLine("The 2 answers from the quadratic equation are: ")
  Console.WriteLine("{0} and {1}",r1,r2)
 End Sub
End Module