Module VBNet 
 Sub Main()
  Dim number,percentage,formula as Decimal
  Console.WriteLine("Enter 2 input, percentage and the number") 
  percentage = Console.ReadLine()
  number = Console.ReadLine()
  formula = (number * percentage) / 100 
  Console.WriteLine("{0}% of {1} is {2}",percentage,number,formula)
 End Sub 
End Module