Module CalderonKhianTask5NetTechnology
    Sub Main()
        Console.clear()
        Dim x as Integer
        x = Math.Ceiling(Rnd() * 3)
        Console.WriteLine("")
        If x=1
        Console.WriteLine("The Generated Random number is 1")
        ElseIf x=2
        Console.WriteLine("The Generated Random number is 2")
        Else
        Console.WriteLine("The Generated Random number is not 1 nor 2")
        End If
        Console.WriteLine("")
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("11 - Demeter")
    End Sub
End Module