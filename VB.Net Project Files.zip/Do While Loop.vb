Module VBNet
 Sub Main()
  Dim x as Integer
  x = Console.ReadLine()
  Console.WriteLine("")
  Do
   Console.WriteLine("X is {0}",x)
   x -= 200
  Loop while x >= 3000 
  Console.WriteLine("")
  Console.WriteLine("Khian Victory D. Calderon")
  Console.WriteLine("11 - Demeter")
 End Sub
End Module