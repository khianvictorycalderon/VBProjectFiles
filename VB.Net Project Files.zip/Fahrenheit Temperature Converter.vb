Module NetTechnologyTask3KhianCalderon 'tells a module name
 Sub Main() 'entry point of the program
   Console.clear() 'clears the console
   Dim f,c,k,r as Double
   Console.WriteLine("Temperature Calculator")'prints this message
   Console.WriteLine("Enter temperature in fahrenheit")'prints this message
   Console.WriteLine("")'serves as a placeholder
   f = Console.ReadLine()'read user input and assign it to variable fahrenheit
   Console.WriteLine("")'serves as a placeholder
   
   c = (f - 32) * 5/9 'centigrade formula
   k = (f + 459.67) * 5/9 'kelvin formula
   r = f + 459.67 ' rankine formula
   
   Console.WriteLine("Fahrenheit : {0}",f)'prints fahrenheit
   Console.WriteLine("Centigrade : {0}",c)'prints centigrade
   Console.WriteLine("Kelvin : {0}",k)'prints kelvin
   Console.WriteLine("Rankine : {0}",r)'prints rankine
   
   Console.WriteLine("")'serves as a placeholder
   Console.WriteLine("Khian Victory D. Calderon")'prints this message
   Console.WriteLine("11 - ICT Demeter")'prints this message
 End Sub 'encloses the sub main
End Module 'encloses the module