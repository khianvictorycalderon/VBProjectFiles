Module KhianVictoryDCalderon_PT_5_11_10_2021_Net_Technology
    Sub Main()
        'declaration'
        Dim P,M,S,F,YP,YM,YS,YF as Decimal
        Dim result as Decimal 'Special final grade variable'
        'P for preliminary , YP for your preliminary , etc...'
        
        'block 1 code section'
        Console.clear()
        Console.WriteLine(" ") 'empty line'
        P = Console.ReadLine()
        M = Console.ReadLine()
        S = Console.ReadLine()
        F = Console.ReadLine()
        Console.WriteLine("Khian Victory D. Calderon")
        Console.WriteLine("Grade 11 - Demeter")
        Console.WriteLine(" ") 'empty line'
        Console.WriteLine("Prelim is 20% of your Grade")
        Console.WriteLine("Midterm is 20% of your Grade")
        Console.WriteLine("Semis is 20% of your Grade")
        Console.WriteLine("Finals is 40% of your Grade")
        Console.WriteLine(" ") 'empty line'
        
        'block 2 code section'
        'variable percentage'
        YP = P * 0.2
        YM = M * 0.2
        YS = S * 0.2
        YF = F * 0.4
        result = (YP + YM + YS + YF)
        
        'block 3 code section'
        Console.WriteLine("Your Prelim Grade is {0}",P)
        Console.WriteLine("Your Midterm Grade is {0}",M)
        Console.WriteLine("Your Semis Grade is {0}",S)
        Console.WriteLine("Your Finals Grade is {0}",F)
        Console.WriteLine(" ") 'empty line'
        Console.WriteLine("Your Final Grade is {0}",result)
        
        'medyo nalito po ako sir nung una hehehehehe'
    End Sub
End Module