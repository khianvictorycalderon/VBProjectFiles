Module ChatBotSystem_by_KhianVictoryDCalderon
 Sub Main()
  '------------------------------------------
  Console.clear()
  Console.WriteLine("Chat Bot System")
  Console.WriteLine("By Khian Victory D. Calderon")
  Console.WriteLine("Grade 11 ICT Demeter")
  
  '-----variables--------
  Dim input as string
  Dim output as string
  Dim con as Integer '0 for false, 1 for true, short for condition
  con = 1
  '----executions and actions-----------
  Console.WriteLine("")
  Console.WriteLine("I type ang salitang exit para matapos ang program")
  Console.WriteLine("Ano ang iyong tanong?")
  While con = 1
   Console.WriteLine("")
   input = Lcase(Console.ReadLine())
   Select Case input
    ' all possible tagalog questions that this program can answer
    'special values
    Case "exit"
     con = 0
	 output = "Salamat!"
    Case ""," ","  ","   ","    ","     ","      " 'for empty spaces loopholes
     output = "Wala ka namang tanong eh, magtanong ka ulit!"
	
    'general questions
    Case "ilang taon ka na?","gaano ka katanda?","anong edad mo?","anong edad mo na?"
     output = "Wala akong gulang dahil ako ay computer program"
    Case "taga saan ka?","saan ka nakatira?"
     output = "Ako ay nakatira sa loob ng compiler"
    Case "sino ka?","sino ka ba?","sino ka ba talaga?"
     output = "Ako si chat bot na ginawa ni khian calderon :)"
    Case "kamusta ka?"
	 output = "Ayos lang naman, dahil wala akong nararamdaman, manhid ako"
	Case "ano na?"
	 output = "Wala, gawa gawa lang"
	Case "ano maitutulong ko sa iyo?","anong maitutulong ko sayo?","anong maitutulong ko sa iyo?","ano maitutulong ko sayo?"
	 output = "Ang bait mo naman, ako dapat nagtatanong niyan sa iyo"
	Case "may pamilya ka ba?"
	 output = "Wala dahil ako ay isang computer program"
	Case "may alam ka ba?"
	 output = "Depende sa nagtatanong :)"
	Case "mahal mo ba ako?"
     output = "Hindi, dahil hindi ako marunong magmahal"
    Case "ano itatanong ko?"
     output = "Kahit ano na mayroon sa database ng program na ito"
    Case "anong height mo?","ano height mo?","gaano ka katangkad?","gaano ka kataas?"
     output = "Wala akong height dahil ako ay computer program"	 
	Case "kilala mo ba ako?","kilala mo ako?"
     output = "Hindi kita kilala, dahil hindi naman ako nakakakilala"
	Case "nasaan ka ngayon?","nasan ka ngayon?","nasan ka?","nasaan ka?"
     output = "Nasa puso mo, Ayiee! joke lang, nasa loob ako ng compiler ngayon"
	Case "sino ako?"
     output = "Ikaw ay isang tao nagbabasa ng code o output na ito"
	Case "ano ang ginagawa ko ngayon?"
     output = "Sikretong malupit, pwedeng pabulong HAHAHHA :)"
	Case "gaano ka kabigat?"
     output = "Siguro mga nasa 1 to the quintillion gram na negative exponent, dahil ako ay isang electron"
	Case "bakit iniwan niya ako?"
     output = "Hindi ko na problema yan, bakit di siya ang tanungin mo"
	Case "nasaan ako ngayon?","nasan ako ngayon?"
     output = "Nagbabasa ng output at source code :)"
    Case "gusto mo ba ang tao?"
     output = "Pag mabait Oo, pag hindi, 7x+20y=0"
	Case "anong hilig mong gawin?","ano hilig mong gawin?"
     output = "Mahilig ako mag... wala akong hilig eh"
	Case "ano ka?","ano ka ba?"
     output = "Ako ay isang Chat Bot na ginawa ni Khian Calderon"
	Case "sinong gusto mo?"
     output = "Parehas, ayaw ko sa kanila :("
	Case "bakit?"
     output = "Anong bakit? pakikumpleto ng tanong"
	Case "bakit iniwan niya ako?"
     output = "Dahil wala kang kasama ngayon"
	Case "ano ang vb net?"
     output = "isang programming language na ginamit sa paggawa nito"
	Case "sino ang guro ni khian?","sino ang teacher ni khian?","sinong teacher ni khian?","sinong guro ni khian?"
     output = "Si sir raymond rabano na magaling magturo, ehem plus points HAHAHAHA, joke lang hehehe :)."
	Case "sino?"
     output = "Ano? pakikumpleto ng tanong"
	Case "sino kausap mo?"
     output = "Ikaw ang kausap ko"
	Case "kelan?"
     output = "Kelan ano? Pakikumpleto ng tanong"
	Case "kelan siya babalik?"
     output = "Babalik siya sa tamang panahon or hindi na siya babalik"
	Case "bakit ba?"
     output = "Secret..."
	Case "paano?","pano?"
     output = "Paanong ano? Paano na kayo? Pakikumpleto ng tanong"
	Case "paano kung"
     output = "Paano kung ano? Pakikumpleto ng tanong"
	Case "paano kung tao ka?"
     output = "Edi ayos"
	Case "ano sa palagay mo?"
     output = "Wala akong mapalagay"
	Case "nagmahal ka na ba?"
     output = "Hindi pa dahil ako ay isang computer program"
	Case "anong ginagawa mo?","anong ginagawa mo ngayon?","ano ginagawa mo ngayon?","ano ginagawa mo ngayon?"
     output = "Nag aayos ng code... :)"
	Case "anong pangalan mo?","ano pangala mo?"
     output = "Ang pangalan ko ay CHATBOT"
	Case "anong araw ngayon?"
     output = "Araw ng pagbasa ng output at source code :)"
	Case "sinong gumawa sayo?","sino gumawa sayo?","sinong gumawa sa iyo?","sino gumawa sa iyo?"
     output = "Si Khian Victory D. Calderon ng 11 Demeter ng ARK (2021-2022)"
	Case "matalino ka ba?"
     output = "Minsan, minsan ay hindi"
	'end of general questions
	
    'if the question is not on the list
    Case Else 
     output = "Pasensya na, wala pa akong sagot diyan"
   End Select
   Console.WriteLine("{0}",output)
  End While
  '------------------------------------------
 End Sub
End Module


' preset only: 
'
' Case ""
'  output = ""