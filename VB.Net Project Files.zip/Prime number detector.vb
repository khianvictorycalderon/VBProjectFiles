Module VBModule
  Sub Main()
    Console.Writeline("Enter any number: ")
    Dim number As Integer
    Dim count As Integer = 0
    number = Console.ReadLine()
    For i As Integer = 1 To number
     If number Mod i = 0 Then
      count += 1
     End If
    Next
    If count = 2 Then
    Console.WriteLine("{0} is a Prime Number.",number)
    Else
    Console.WriteLine("{0} is not a Prime Number.",number)
    End If
  End Sub
End Module
